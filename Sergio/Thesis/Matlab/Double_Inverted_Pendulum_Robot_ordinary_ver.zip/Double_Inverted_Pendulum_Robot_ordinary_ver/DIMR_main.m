%%% This is a m-file for DIMR.slx. %%%
%%% You have to run it in "/Double_Inverted_Pendulum_Robot_ordinary_ver.%%%
%% incantation
close all;
clear;

%% Path of directories
dir_current = cd;
dir_model = fullfile(dir_current,"model");
dir_control = fullfile(dir_current,"controller");

%% Initial and nominal conditions
theta_p0 = -10*pi/180; %initial pitch angle[rad] 
theta_f0 = 100*pi/180; %initial fork angle[rad]
theta_pn = 0*pi/180; %nominal pitch angle[rad]
theta_fn = 90*pi/180; %nominal pitch angle[rad]

%% Command generation
theta_p_cmd = 0*pi/180; %pitch angle cmd[rad]
theta_f_cmd = 90*pi/180-theta_p_cmd; %fork angle cmd[rad]
phi_cmd = 0*pi/180; %yaw angle cmd[rad]

%% Load robot configuration
cd(dir_model);
model_params_with_errors;
model_params_without_errors;
model_params_env;
cd(dir_current);

cd(dir_control);
controller_init;
controller_PD_DOB
cd(dir_current);
