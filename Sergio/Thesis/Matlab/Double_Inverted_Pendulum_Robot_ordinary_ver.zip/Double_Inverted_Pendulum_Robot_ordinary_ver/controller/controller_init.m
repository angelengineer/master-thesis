%%% Controller iniatialization parameters %%%
%% Sampling time
T_control = 1e-3; %sampling time of controller[s]

%% Low pass filter
omega_c = 5000; %cut-off angular frequency for pseudo derivative[rad/s]