%%% PD + DOB parameters %%%
%% Nominal parameter
I_bx = M_b*(L_by^2+L_bz^2)/12; %body main inertia in x[kgm^2]
I_by = M_b*(L_bx^2+L_by^2)/12; %body main inertia in y[kgm^2]
I_bz = M_b*(L_bz^2+L_bx^2)/12; %body main inertia in y[kgm^2]

I_wx = M_w*(R_wo^2+R_wi^2+W_w^2/3)/4; %wheel main inertia in x[kgm^2]
I_wy = M_w*(R_wo^2+R_wi^2)/2; %wheel main inertia in y[kgm^2]
I_wz = I_wx; %wheel main inertia in z[kgm^2]

I_fx = M_f*(L_fy^2+L_fz^2)/12; %fork main inertia in x[kgm^2]
I_fy = M_f*(L_fx^2+L_fy^2)/12; %fork main inertia in y[kgm^2]
I_fz = M_f*(L_fz^2+L_fx^2)/12; %fork main inertia in z[kgm^2]

M_n11 = (M_b+2*M_w+M_f)+2*I_wy/R_wo^2;
M_n22 = M_b*L_bg^2*(sin(theta_pn))^2+I_bx*(sin(theta_pn))^2+...
        I_bz*(cos(theta_pn))^2+2*M_w*L_wt^2+...
        2*I_wz+M_f*(L_by*sin(theta_pn)+L_fg*sin(theta_pn+theta_fn))^2+...
        I_fx*(sin(theta_pn+theta_fn))^2+I_fz*(cos(theta_pn+theta_fn))^2+...
        +2*L_wt^2*I_wy/R_wo^2;
M_n33 = M_b*L_bg^2+I_by+M_f*(L_by^2+L_fg^2+2*L_by*L_fg*cos(theta_fn))+...
        I_fy;
M_n31 = M_b*L_bg*cos(theta_pn)+...
        M_f*(L_by*cos(theta_pn)+L_fg*cos(theta_pn+theta_fn));
M_n44 = M_f*L_fg^2+I_fy;

%% Pitch angle
K_pp = 100; %pitch angle position gain[/s^2]
K_pd = 20; %pitch angle derivative gain[/s]
g_spado = 2*pi*10; %cut-off angular frequency[rad/s]

%% Yaw angle
K_yp = 100; %yaw angle position gain[/s^2]
K_yd = 20; %yaw angle derivative gain[/s]
g_yaw = 2*pi*100; %cut-off angular frequency[rad/s]

%% Fork angle
K_fp = 100; %fork angle position gain[/s^2]
K_fd = 20; %fork angle derivative gain[/s]
g_fork = 2*pi*100; %cut-off angular frequency[rad/s]