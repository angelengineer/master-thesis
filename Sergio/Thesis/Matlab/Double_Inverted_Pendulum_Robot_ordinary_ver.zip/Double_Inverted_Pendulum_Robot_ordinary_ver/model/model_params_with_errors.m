%%% Hardware parameters with modeling errors %%%
%% Body
M_b = 43.1; %body mass[kg]
L_bx = 0.20; %body depth[m]
L_by = 0.40; %body height[m]
L_bz = 0.52; %body width[m]
D_b = M_b/(L_bx*L_by*L_bz); %body density[kg/m^3]
L_bg = L_by/2; %distance between COG of body and wheel axis[m]

%% Wheel
M_w = 1.21; %wheel mass[kg]
R_wo = 0.075; %wheel outer radius[m]
R_wi = 0.055; %wheel inner radius[m]
W_w = 0.025; %wheel width[m]
D_w = M_w/(pi*(R_wo^2-R_wi^2)*W_w); %wheel density[kg/m^3]
L_wt = (L_bz+W_w)/2; %half of tread[m]

%% Fork
M_f = 3.5; %fork mass[kg]
L_fx = 0.50; %fork length[m]
L_fy = 0.40; %fork width[m]
L_fz = 0.01; %fork thickness[m]
D_f = M_f/(L_fx*L_fy*L_fz); %fork density[kg/m^3]
L_fh = L_by; %distance between bottom of body and fork[m]
L_fg = L_fx/2; %distance between COG of fork and fork axis[m]
